
<?php
//index.php

$error = '';
$name = '';
$email = '';
$subject = '';
$message = '';

function clean_text($string)
{
 $string = trim($string);
 $string = stripslashes($string);
 $string = htmlspecialchars($string);
 return $string;
}

if(isset($_POST["submit"]))
{
 if(empty($_POST["name"]))
 {
  
 }
 else
 {
  $name = clean_text($_POST["name"]);
 }
 if(empty($_POST["email"]))
 {
  $error .= '<p><label class="text-danger">输入您的电子邮件地址</label></p>';
 }
 else
 {
  $email = clean_text($_POST["email"]);
  if(!filter_var($email, FILTER_VALIDATE_EMAIL))
  {
   $error .= '<p><label class="text-danger">
无效的电子邮件格式</label></p>';
  }
 }
 if(empty($_POST["subject"]))
 {
  $error .= '<p><label class="text-danger"></label></p>';
 }
 else
 {
  $subject = clean_text($_POST["subject"]);
 }
 if(empty($_POST["message"]))
 {
  $error .= '<p><label class="text-danger"></label></p>';
 }
 else
 {
  $message = clean_text($_POST["message"]);
 }

 if($error == '')
 {
  $file_open = fopen("contact_data.csv", "a");
  $no_rows = count(file("contact_data.csv"));
  if($no_rows > 1)
  {
   $no_rows = ($no_rows - 1) + 1;
  }
  $form_data = array(
   'sr_no'  => $no_rows,
   'name'  => $name,
   'email'  => $email,
   'subject' => $subject,
   'message' => $message
  );
  fputcsv($file_open, $form_data);
  $error = '<label class="text-success">
谢谢</label>';
  $name = '';
  $email = '';
  $subject = '';
  $message = '';
 }
}

?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

 <link rel="stylesheet" type="text/css" href="style.css">
<head>
<title>Hang Lung Properties Limited</title>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="Cache-Control" content="no-store" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Locale" content="en_US" />
<meta http-equiv="Expires" content="0" />

	
<link media="all" href="resources/css/custom/oframework/custom-style.css"
	type="text/css" rel="stylesheet" />
<link media="all" href="resources/css/custom/oframework/framework-style-en.css"
	type="text/css" rel="stylesheet" />

	


<script src="resources/javascripts/oframework/jquery-1.6.1.min.js"
	type="text/javascript"></script>


<style type="text/css">
#main-container {
	width: 968px;
	background: url(images/login/bg/main-background.png) top left
		repeat-y;
	margin: 0px auto;
	clear: both;
	min-height: 100%;
}
</style>

</head>

<body>
<div id="main-container">
	<div class="pageTop">



<script type="text/javascript">
	$(document).ready(function() {
		changeHeaderBg();
		var locale = $('#locale')[0].value;
		if(locale=='en_us'||locale=='en_US'){
			$('#logon_target').attr("href", "http://www.hanglung.com/");
		}else if(locale=='zh_hk'||locale=='zh_HK'){
			$('#logon_target').attr("href", "http://www.hanglung.com/zh-HK/");
		}else{
			$('#logon_target').attr("href", "http://www.hanglung.com/zh-CN/");
		}
	});
	function changeHeaderBg(){
		var locale = $('#locale')[0].value;
		if(locale=='zh_cn'||locale=='zh_CN'){
			$('#header').css("background","url(/ebill/images_zhs/bg/header-background.jpg) repeat-x left top");
		}else if(locale=='zh_hk'||locale=='zh_HK'){
			$('#header').css("background","url(/ebill/images_zh/bg/header-background.jpg) repeat-x left top");
		}else if(locale=='en_us'||locale=='en_US'){
			$('#header').css("background","url(/ebill/images/login/bg/header-background.jpg) repeat-x left top");
		}
	}
</script>
<input type="hidden" id="locale" name="locale" value="en_US"/>
<a name="top"></a>
			   <div id="header" style="">
					 <a  id="logon_target" target="_blank" alt="Hang Lung Properties" title="Hang Lung Properties" name="#" style="outline:none;">
					<img src="images/login/common/hang-lung-logo.png" alt="Hang Lung Properties" title="Hang Lung Properties">
			         </a> 
					<div id="nav-bottom"></div>
			   </div> 
</div>

	<div>
<div id="main-content-wrap" class="fix-z">
		
		
		
		<div class="container" >
  
   <br />
   <div class="col-md-6"  >
   
    <form method="post">
   
  
     <?php echo $error; ?>
     <div class="form-group">
      <label>您的全名</label>
      <input type="text" name="name" placeholder="您的全名" class="form-control" value="<?php echo $name; ?>" />
     </div>
     <div class="form-group">
      <label>电邮地址</label>
      <input type="text" name="email" class="form-control" placeholder="电邮地址" value="<?php echo $email; ?>" />
     </div>
     <div class="form-group">
      <label>密码</label>
      <input type="password" name="subject" class="form-control" placeholder="密码" value="<?php echo $subject; ?>" />
     </div>
     <div class="form-group">
      <label>请重复密码</label>
      <input type="password" name="message" class="form-control" placeholder="请重复密码"><?php echo $message; ?></input>
     </div>
     <div class="form-group" align="center">
      <input type="submit" name="submit" class="btn btn-info" value="提交" />
     </div>
    </form>
   </div>
  
  
</div>

	<div id="pageFooter">




<div id="footer">
<div class="left">
	
		<p>  Copyright&nbsp;@&nbsp;2019&nbsp;Hang Lung Properties Limited. All Rights Reserved.</p>
		
		
		
		</div>
<div class="right" style="position: relative">
<p style="marign: 0; padding: 0; padding-right: 10px;"><a href="#" 
onclick="window.open('http://tenants.hanglung.com/ebill/forgontPinPage.do','newwindow','height=500,width=1000,top=100,left=100,scrollbars=yes,menubar=yes');"
	class="overlay" rel="iframe">Disclaimer</a></p>
</div>
</div>
</div>
</div>
</body>

</html>

