
// shows or hides a DIV element
// divID - name of the DIV element
// show - true (show) or false (hide)
function winShow(ID, show) {
if (show == null || typeof(show) == 'undefined') show = true;

var el = document.getElementById(ID);
if (el) {
if (show) {
// set the object visible
el.style.visibility = "visible";

// make sure it's not off-screen...
//   top-left of the object (relative to the page)
var objLft = 0;
var objTop = 0;
for (var e = el; e.offsetParent; e = e.offsetParent) {
objLft += e.offsetLeft;
objTop += e.offsetTop;
}
//   bottom-right of the object
var objRgt = objLft + el.offsetWidth;
var objBtm = objTop + el.offsetHeight;
//   leave some margin around the object
var margin = 2;
objLft -= margin; objTop -= margin;
objRgt += margin; objBtm += margin;
//   page scroll position
var winX = document.body.scrollLeft;
var winY = document.body.scrollTop;
//   page size
var winW = document.body.clientWidth;
var winH = document.body.clientHeight;
//   move the object on-screen
if (objRgt > winX+winW) winX = objLft - winW; // right edge
if (objBtm > winY+winH) winY = objBtm - winH; // bottom edge
if (objLft < winX) winX = objLft; // left edge
if (objTop < winY) winY = objTop; // top edge
window.scrollTo(winX, winY);
} else {
// set the object invisible
el.style.visibility = "hidden";
}
}
}

function winHide(ID) {
winShow(ID, false);
}

function winSetHeight(ID, height) {
var element = document.getElementById(ID);
if (element) element.style.height = height + "px";
}

function winAutoHeight(ID, nonClientHeight) {
var myHeight = 0;
if( typeof( window.innerHeight ) == 'number' ) {
//Non-IE
myHeight = window.innerHeight;
} else if( document.documentElement && document.documentElement.clientHeight ) {
//IE 6+ in 'standards compliant mode'
myHeight = document.documentElement.clientHeight;
} else if( document.body && document.body.clientHeight ) {
myHeight = document.body.clientHeight;
}
winSetHeight(ID, myHeight - nonClientHeight);
}

function getElementHeight(ID) {
var height = 0;
var elem = document.getElementById(ID);
if (elem)
height = elem.offsetHeight;
return height;
}