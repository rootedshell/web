<?php
header("Location:http://tenants.hanglung.com/ebill/login.do");
exit;
?>